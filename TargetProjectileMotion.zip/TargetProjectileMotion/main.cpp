#include "mainwindow.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.setWindowTitle("Kristian Lung Lotama's Bullet Simulation Program");
    w.show();
    return a.exec();
}
