#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QGraphicsScene>
#include <QGraphicsLineItem>
#include <QtMath>
#include <QMessageBox>

QGraphicsScene *scene = nullptr;
int currentWeapon = 0; // Variable to store the current weapon

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    double X = ui->xdistance->value();
    double Y = ui->ydistance->value();
    double Diameter = ui->targetdiameter->value();
    double Yshotref = ((Diameter / 2) + Y);

    // Variable Weapon Specs
    double timeMultiplier = 0.0;
    double gravityMultiplier = 0.0;

    // Array to store variables
    if (ui->AK47->isChecked()) {
        timeMultiplier = 715.0;
        gravityMultiplier = 9.81;
        currentWeapon = 1;
    } else if (ui->MG98->isChecked()) {
        timeMultiplier = 639.0;
        gravityMultiplier = 9.81;
        currentWeapon = 2;
    } else if (ui->MN->isChecked()) {
        timeMultiplier = 865.0;
        gravityMultiplier = 9.81;
        currentWeapon = 3;
    } else if (ui->AR15->isChecked()) {
        timeMultiplier = 1006.0;
        gravityMultiplier = 9.81;
        currentWeapon = 4;
    } else if (ui->M4->isChecked()) {
        timeMultiplier = 910.0;
        gravityMultiplier = 9.81;
        currentWeapon = 5;
    } else if (ui->M16->isChecked()) {
        timeMultiplier = 960.0;
        gravityMultiplier = 9.81;
        currentWeapon = 6;
    } else if (ui->LE->isChecked()) {
        timeMultiplier = 744.0;
        gravityMultiplier = 9.81;
        currentWeapon = 7;
    } else if (ui->SKS->isChecked()) {
        timeMultiplier = 735.0;
        gravityMultiplier = 9.81;
        currentWeapon = 8;
    } else if (ui->MP->isChecked()) {
        timeMultiplier = 315.0;
        gravityMultiplier = 9.81;
        currentWeapon = 9;
    } else if (ui->G19->isChecked()) {
        timeMultiplier = 375.0;
        gravityMultiplier = 9.81;
        currentWeapon = 10;
    } else if (ui->DE->isChecked()) {
        timeMultiplier = 470.0;
        gravityMultiplier = 9.81;
        currentWeapon = 11;
    }

    double time = sqrt((2*Yshotref) / gravityMultiplier);
    double Xshotresult = timeMultiplier * time;
    double time2 = X / timeMultiplier;
    double Yshotresult = 0.5 * gravityMultiplier * (time2 * time2);
    double Yshotref2 = Yshotref - Yshotresult;
 qDebug() << "Yshotref2:" << Yshotref2;
    if (!scene)
    {
        scene = new QGraphicsScene(this);
        ui->graphicsView->setScene(scene);
    }
    else
    {
        scene->clear();
    }

    // For drawing the bullet trajectory
    QGraphicsLineItem *redbulletPath = new QGraphicsLineItem(0, 0, Xshotresult, Yshotref); // Adjust size as needed
    QPen redPen(Qt::red);
    redPen.setWidth(10);  // Set the width of the line
    redbulletPath->setPen(redPen);
    scene->addItem(redbulletPath);

    QGraphicsLineItem *bluebulletPath = new QGraphicsLineItem(X, 0, Xshotresult, Yshotref); // Adjust size as needed
    QPen bluePen(Qt::blue);
    bluePen.setWidth(15);  // Set the width of the line
    bluebulletPath->setPen(bluePen);
    scene->addItem(bluebulletPath);
    scene->setSceneRect(0, 0, Xshotresult, Yshotref);
    ui->graphicsView->fitInView(scene->sceneRect(), Qt::KeepAspectRatio);
    // Output Results
    if (Xshotresult >= X && Diameter >= Yshotref2) {
        ui->textBrowser->setText("The bullet will hit the target in " + QString::number(time2) + " seconds");
        ui->textBrowser->append("If the target is not present, it will hit the ground in " + QString::number(time) + " seconds");
    } else {
        ui->textBrowser->setText("The bullet will not hit the target");
        ui->textBrowser->append("It will hit the ground in " + QString::number(time) + " seconds");
    }
}
void MainWindow::onGraphicsViewDestroyed()
{
    if (scene)
    {
        delete scene;
        scene = nullptr;
    }
}

void MainWindow::on_pushButton_2_clicked()
{
    QMessageBox msgBox;
    msgBox.setWindowTitle("Kristian Lung Lotama Algorithm Explanation");
    msgBox.setTextFormat(Qt::RichText);
    QString Text1 = tr("<strong>This is the explanation of my program</strong> \n" );
    QString Text2 = tr("<br />My program is created to calculate the time it takes a bullet to travel to a target \n");
    QString Text3 = tr("<br />My program also shows the trajectory of the bullet \n");
    QString Text4 = tr("<br /><strong>mainwindow.h</strong> contains the code to store the variables used to calculate the equations. \n");
    QString Text6 = tr("<br /><strong>main.cpp</strong> contains the code that sets the window title to my name. \n");
    QString Text7 = tr("<br /><strong>mainwindow.cpp</strong> contains the code that deals with the output of results and a few calculations when the buttons are pressed \n");
    msgBox.setText(Text1 + Text2 + Text3 + Text4 + Text6 + Text7);
    msgBox.exec();
}

