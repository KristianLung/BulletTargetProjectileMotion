#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QRadioButton>
#include <QGraphicsScene>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

struct WeaponParameters {
    int timeMultiplier;
    int gravityMultiplier;
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_clicked();
    void onWeaponButtonClicked();
    void onGraphicsViewDestroyed();

    void on_pushButton_2_clicked();

private:
    Ui::MainWindow *ui;
    double X, Y, Diameter, Xshotresult, Yshotresult, Xshotref, Yshotref, Yshotref2, time, time2;
    int one, two, three, four, five, six, seven, eight, nine, ten, eleven;
    WeaponParameters weaponParams[11];
    QRadioButton* weaponButtons[11];
    QGraphicsScene* scene;
    QGraphicsView* view;
};

#endif // MAINWINDOW_H
